$(document).ready(function () {
    changeSliderImage();
    sticky();
    loadData();
    $('#loginBtn').click(function () {
        login();
    });
    xemTour();
    $(document).on('click', '.view-tour', function () {
        let tourId = $(this).data('id');
        xemTour(tourId);
    });
    loadDataAdmin();
    $("#addTour").click(function (e) {
        e.preventDefault();
        addTour();
    });
});

function changeSliderImage() {
    var images = $('#Slider img'); 
    var index = 0;

    function showNextImage() {
        $(images[index]).removeClass('active'); 
        index = (index + 1) % images.length; 
        $(images[index]).addClass('active'); 
    }

    setInterval(showNextImage, 3000);
}

function sticky() {
    const header = document.querySelector("header")
    window.addEventListener("scroll",function(){
        x = window.pageYOffset
        if(x > 0) {
            header.classList.add("sticky")
        }
        else {
            header.classList.remove("sticky")
        }
    })
}

function loadData() {
    $.ajax({
        url: 'https://67b6a98407ba6e590841404d.mockapi.io/api/v1/user', 
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        success: function (response) {
            let row = '';
            let i = 1;

            $.each(response, function (index, tour) {
                row += '<div class="product">';
                row += '<div class="time">ngày ' + tour.time + '</div>';
                row += '<img src="' + tour.imageURL + '" alt="' + tour.name + '">';
                row += '<h3>' + tour.name + '</h3>';
                row += '<p class="price">' + tour.price + '₫</p>';
                row += '<p class="promotion">' + tour.promotion + '</p>';
                row += '<button class="btn btn-outline-danger view-tour" data-id="' + tour.id + '">Xem tour</button>';
                row += '</div>';
                i++;
            });

            $("#content").html(row);
        },
        error: function (e) {
            console.log("Lỗi:", e);
        }
    });
}

function login() {
    var email = $('#email').val();
    var password = $('#password').val();
    var role = $('#role').val();

    var users = [
        { email: "email", password: "admin123", role: "admin" },
        { email: "email", password: "user123", role: "user" }
    ];

    var foundUser = users.find(user => user.email === email && user.password === password && user.role === role);

    if (foundUser) {
        if (role === "admin") {
            alert("Đăng nhập thành công");
            window.location.href = "admin.html"; 
        } else {
            alert("Chào mừng Khách hàng");
            window.location.href = "user.html"; 
        }
    } else {
        alert("Tài khoản hoặc mật khẩu không đúng!");
    }
}

function xemTour(tourId) {
    $.ajax({
        url: `https://67b6a98407ba6e590841404d.mockapi.io/api/v1/user/${tourId}`,
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        success: function (tour) {
            let row = '';
            let rowname = '';
            rowname += tour.name;
            row += '<img class="image-row" src="' + tour.imageURL + '" alt="' + tour.name + '">';
            row += '<div class="time">ngày ' + tour.time + '</div>';
            row += '<p class="price">Giá: ' + tour.price + '₫</p>';
            row += '<p class="promotion">Ưu đãi:' + tour.promotion + '</p>';
            row += '<p class="note">Lịch trình chi tiết: ' +tour.note + '</p>';
            // Hiển thị modal
            $('#xemTour .modal-body').html(row);
            $('#xemTour .modal-title').html(rowname);
            $('#xemTour').modal('show');
        },
        error: function (error) {
            console.log("Lỗi khi tải dữ liệu tour:", error);
        }
    });
}

function clickAddCart() {
    alert("Vui lòng đăng nhập!");
}

function loadDataAdmin() {
    $.ajax({
        url: 'https://67b6a98407ba6e590841404d.mockapi.io/api/v1/user', 
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        success: function (response) {
            let row = '';
            let i = 1;

            $.each(response, function (index, tour) {
                row += '<div class="product">';
                row += '<div class="time">ngày ' + tour.time + '</div>';
                row += '<img src="' + tour.imageURL + '" alt="' + tour.name + '">';
                row += '<h3>' + tour.name + '</h3>';
                row += '<p class="price">' + tour.price + '₫</p>';
                row += '<p class="promotion">' + tour.promotion + '</p>';
                row += '<button class="btn btn-primary view-tour" data-id="' + tour.id + '">Xem tour</button>';
                row += '<br></br>';
                row += '<button class="btn btn-danger" onclick="deleteTour(' + tour.id + ')">Xóa</button>';
                row += '</div>';
                i++;
            });

            $("#content-admin").html(row);
        },
        error: function (e) {
            console.log("Lỗi:", e);
        }
    });
}

function deleteTour(id){
    if(confirm('Bạn có đồng ý xóa tour có id: ' + id + '?')){
        $.ajax({
            url: 'https://67b6a98407ba6e590841404d.mockapi.io/api/v1/user/' + id,
            type: 'DELETE',
            dataType: 'json',
            success: function(response){
                alert("Xóa thành công");
                loadDataAdmin(); 
            },
            error: function(e){
                console.log("Lỗi:", e);
            }
        });
    }
}

function addTour() {
    let name = $("#tourName").val();
    let imageURL = $("#tourImage").val();
    let time = $("#tourTime").val();
    let price = $("#tourPrice").val();
    let promotion = $("#tourPromotion").val();

    if (name == "" || imageURL == "" || time == "" || price == "") {
        alert("Vui lòng nhập đầy đủ thông tin");
        return;
    }

    $.ajax({
        url: 'https://67b6a98407ba6e590841404d.mockapi.io/api/v1/user',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            name: name,
            imageURL: imageURL,
            time: time,
            price: price,
            promotion: promotion,
        }),
        success: function (response) {
            alert("Thêm tour thành công!");
            $("#addTourForm")[0].reset(); 
            loadDataAdmin(); 
        },
        error: function (e) {
            alert("Lỗi khi thêm tour: " + e);
        }
    });
}